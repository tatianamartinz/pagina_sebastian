﻿(function () {
    //var URL = "http://localhost:47646/GestionMovil/Ecommerce/shoexpress/Servicios/contactos.asmx/CopiarCatalogo";
    
    var URL = "http://vtazure.cloudapp.net:8080/maravilla/Doom/Bootstrap/Ecommerce/shoexpress/Servicios/contactos.asmx/CopiarCatalogo";

    RecibeCopiar = function () {
        var sms_error = "";
        var correo_copiar = "";
        var correo_origen = "";
        var obs_copiar = "";

        correo_copiar = $("#txtdestino").val();
        if (isValidEmailAddress(correo_copiar) == false) {
            sms_error = sms_error + "direccion de correo origen no valida.";
            $("#txtdestino").val("")
        }
        correo_origen = $("#txtorigen").val();
        if (isValidEmailAddress(correo_origen) == false) {
            sms_error = sms_error + "direccion de destino no valida.";
            $("#txtorigen").val("")
        }
        if (sms_error == "") {
            Copiar($("#txtdestino").val(), $("#txtorigen").val(), $("#txtobs").val() );
        }
        else {
            sweetAlert("Oops...", "Debes ingresar " + sms_error, "error")
        }
    }

    function isValidEmailAddress(emailAddress) {
        var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
        return pattern.test(emailAddress);
    };


    Copiar = function (destino, origen, obs) {
        var consulta = ""
        consulta = consulta + "<PagXml>                              ";
        consulta = consulta + "   <Param>                            ";
        consulta = consulta + "      <CAMPO>CORREO</CAMPO>            ";
        consulta = consulta + "      <VALOR><![CDATA[" + origen + "]]></VALOR>     ";
        consulta = consulta + "   </Param>                           ";
        consulta = consulta + "   <Param>                            ";
        consulta = consulta + "      <CAMPO>DESTINOS</CAMPO>            ";
        consulta = consulta + "      <VALOR><![CDATA[ " + destino + "  ]]></VALOR>     ";
        consulta = consulta + "   </Param>                           ";

        consulta = consulta + "   <Param>                            ";
        consulta = consulta + "      <CAMPO>MENSAJE</CAMPO>            ";
        consulta = consulta + "      <VALOR><![CDATA[ " + obs + "  ]]></VALOR>     ";
        consulta = consulta + "   </Param>                           ";

        consulta = consulta + "   <Param>                            ";
        consulta = consulta + "      <CAMPO>TEMA</CAMPO>            ";
        consulta = consulta + "      <VALOR><![CDATA[ " + "0055" + "  ]]></VALOR>     ";
        consulta = consulta + "   </Param>                           ";

        //consulta = consulta + "   <Param>                            ";
        //consulta = consulta + "      <CAMPO>ADJUNTAR</CAMPO>            ";
        //consulta = consulta + "      <VALOR><![CDATA[ " + "D:@TTXcampaña4.pdf" + "  ]]></VALOR>     ";
        //consulta = consulta + "      <VALOR><![CDATA[ " + "C:@TTXinetpub@TTXwwwroot@TTXMaravilla@TTXcomunicados@TTXcopialo@TTXcampaña4.pdf" + "  ]]></VALOR>     ";
        //consulta = consulta + "   </Param>                           ";
        consulta = consulta + "</PagXml>                             ";


        //alert(consulta);
        //$("#txtmensaje").val(consulta);

        jQuery.ajax({
            type: "POST",
            url: URL,
            data: "Parametros=" + consulta + "",
            success: function (data) {
                alert("Contacto enviado");
                // En caso de que retorne datos
                var xml_string = jQuery(data).text();
                //alert(xml_string);
                swal("Good job!", "Ya fue enviado tu correo!", "success")
                $(xml_string).find('Datos').each(function () {
                });
            },
            error: function (xhr, msg) {
                //alert("err:" + msg + '\n' + xhr.responseText);
                swal("Good job!", "Ya fue enviado tu correo!", "success")
            }
        })
    }

   

})();