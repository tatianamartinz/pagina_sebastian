﻿
$(document).ready(function () {
    var URL = "https://3dev.com.co/Doom/Bootstrap/Datos/WebDatos.asmx/FiltroBusqueda";
    

    BuscarItemspt = function (Filtro) {
        var producto = "";

        if (Filtro == "") {
            Filtro = "SUCURSAL= 01 ";
        } else {
            Filtro = Filtro + " , SUCURSAL= 01";
        }

        $('#carusel_portatil').empty();
        $('#carusel_suministros').empty();
        $('#carusel_celular').empty();
        $('#carusel_discos').empty();
        $('#carusel_equipos').empty();
        $('#carusel_memorias').empty();
        $('#carusel_tables').empty();

        producto = "";
        producto = producto + " <div class='owl-wrapper-outer'> ";
        producto = producto + " <div class='owl-wrapper col-md-12' style='left: 0px; display: block;'> ";

        productosum = "";
        productosum = productosum + " <div class='owl-wrapper-outer'> ";
        productosum = productosum + " <div class='owl-wrapper' style=' left: 0px; display: block;'> ";

        productocel = "";
        productocel = productocel + " <div class='owl-wrapper-outer'> ";
        productocel = productocel + " <div class='owl-wrapper' style=' left: 0px; display: block;'> ";

        productodis = "";
        productodis = productodis + " <div class='owl-wrapper-outer'> ";
        productodis = productodis + " <div class='owl-wrapper' style=' left: 0px; display: block;'> ";

        productoequ = "";
        productoequ = productoequ + " <div class='owl-wrapper-outer'> ";
        productoequ = productoequ + " <div class='owl-wrapper' style=' left: 0px; display: block;'> ";

        productomem = "";
        productomem = productomem + " <div class='owl-wrapper-outer'> ";
        productomem = productomem + " <div class='owl-wrapper' style=' left: 0px; display: block;'> ";

        productotab = "";
        productotab = productotab + " <div class='owl-wrapper-outer'> ";
        productotab = productotab + " <div class='owl-wrapper' style=' left: 0px; display: block;'> ";



        var consulta = ""
        consulta = consulta + "<PagXml>                                ";
        consulta = consulta + "   <CorXml>                             ";
        consulta = consulta + "      <TIPO>PARAMETRO</TIPO>            ";
        consulta = consulta + "      <CODIGO>0099</CODIGO>             ";
        consulta = consulta + "      <NOMBRE>PROCESO</NOMBRE>          ";
        consulta = consulta + "      <ORDEN>1</ORDEN>                  ";
        consulta = consulta + "      <VALOR><![CDATA[EMPRESA.CONTACTOS]]></VALOR>   ";
        consulta = consulta + "      <FILTRO><![CDATA[" + Filtro + "]]></FILTRO>     ";
        consulta = consulta + "   </CorXml>                             ";
        consulta = consulta + "</PagXml>                               ";
        //alert(consulta);

        jQuery.ajax({
            type: "POST",
            url: URL,
            data: "Parametros=" + consulta + "",
            success: function (data) {
                var xml_string = jQuery(data).text();
                //$("#textAreaFileSelectedAsText").val(xml_string);
                $(xml_string).find('Datos').each(function () {

                    nombre = $(this).find("NOMBRE").text()
                    precio = $(this).find("PRECIO").text()
                    referencia = $(this).find("REFERENCIA").text()
                    tipo_inven = $(this).find("TIPO_INVEN").text()

                    if (tipo_inven == "PORTATILES") {
                        producto = producto + " <div class='col-md-3' > "
                        producto = producto + " <div class='product-thumb'> "
                        producto = producto + "   <div class='image'><a href='product.html'><img src='https://3dev.com.co/Doom/Bootstrap/(S(dkuvl5elumrtdpvmdge5v35g))/ShowImage.ashx?ID=" + referencia + "&TIPO=FRENTE&COLOR=*&EMPRESA=01' alt='Aspire Ultrabook Laptop' title='Aspire Ultrabook Laptop' class='img-responsive'></a></div> "
                        producto = producto + "   <div class='caption'> "
                        producto = producto + "       <h4><a href='product.html'>" + nombre + "</a></h4> "
                        producto = producto + "       <p class='price'> <span class='price-new'>$" + precio  + "</span> <span class='price-old'>$00.00</span> <span class='saving'>-25%</span> </p> "
                        producto = producto + "       <div class='rating'> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star-o fa-stack-2x'></i></span> </div> "
                        producto = producto + "   </div> "
                        producto = producto + "   <div class='button-group'> "
                        producto = producto + "       <button class='btn-primary' type='button' onclick=''><span>Add to Cart</span></button> "
                        producto = producto + "       <div class='add-to-links'> "
                        producto = producto + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to wishlist'><i class='fa fa-heart'></i></button> "
                        producto = producto + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to compare'><i class='fa fa-exchange'></i></button> "
                        producto = producto + "       </div> "
                        producto = producto + "   </div>"
                        producto = producto + " </div>"
                        producto = producto + " </div>"
                    }
                    if (tipo_inven == "SUMINISTROS") {
                        productosum = productosum + " <div class='owl-item' style='width: 228px;'> "
                        productosum = productosum + " <div class='product-thumb'> "
                        productosum = productosum + "   <div class='image'><a href='product.html'><img src='https://3dev.com.co/Doom/Bootstrap/(S(dkuvl5elumrtdpvmdge5v35g))/ShowImage.ashx?ID=" + referencia + "&TIPO=FRENTE&COLOR=*&EMPRESA=01' alt='Aspire Ultrabook Laptop' title='Aspire Ultrabook Laptop' class='img-responsive'></a></div> "
                        productosum = productosum + "   <div class='caption'> "
                        productosum = productosum + "       <h4><a href='product.html'>" + nombre + "</a></h4> "
                        productosum = productosum + "       <p class='price'> <span class='price-new'>$230.00</span> <span class='price-old'>$" + precio + "</span> <span class='saving'>-25%</span> </p> "
                        productosum = productosum + "       <div class='rating'> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star-o fa-stack-2x'></i></span> </div> "
                        productosum = productosum + "   </div> "
                        productosum = productosum + "   <div class='button-group'> "
                        productosum = productosum + "       <button class='btn-primary' type='button' onclick=''><span>Add to Cart</span></button> "
                        productosum = productosum + "       <div class='add-to-links'> "
                        productosum = productosum + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to wishlist'><i class='fa fa-heart'></i></button> "
                        productosum = productosum + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to compare'><i class='fa fa-exchange'></i></button> "
                        productosum = productosum + "       </div> "
                        productosum = productosum + "   </div>"
                        productosum = productosum + " </div>"
                        productosum = productosum + " </div>"
                    }
                    if (tipo_inven == "CELULARES") {
                        productocel = productocel + " <div class='owl-item' style='width: 228px;'> "
                        productocel = productocel + " <div class='product-thumb'> "
                        productocel = productocel + "   <div class='image'><a href='product.html'><img src='https://3dev.com.co/Doom/Bootstrap/(S(dkuvl5elumrtdpvmdge5v35g))/ShowImage.ashx?ID=" + referencia + "&TIPO=FRENTE&COLOR=*&EMPRESA=01' alt='Aspire Ultrabook Laptop' title='Aspire Ultrabook Laptop' class='img-responsive'></a></div> "
                        productocel = productocel + "   <div class='caption'> "
                        productocel = productocel + "       <h4><a href='product.html'>" + nombre + "</a></h4> "
                        productocel = productocel + "       <p class='price'> <span class='price-new'>$230.00</span> <span class='price-old'>$" + precio + "</span> <span class='saving'>-25%</span> </p> "
                        productocel = productocel + "       <div class='rating'> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star-o fa-stack-2x'></i></span> </div> "
                        productocel = productocel + "   </div> "
                        productocel = productocel + "   <div class='button-group'> "
                        productocel = productocel + "       <button class='btn-primary' type='button' onclick=''><span>Add to Cart</span></button> "
                        productocel = productocel + "       <div class='add-to-links'> "
                        productocel = productocel + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to wishlist'><i class='fa fa-heart'></i></button> "
                        productocel = productocel + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to compare'><i class='fa fa-exchange'></i></button> "
                        productocel = productocel + "       </div> "
                        productocel = productocel + "   </div>"
                        productocel = productocel + " </div>"
                        productocel = productocel + " </div>"
                    }
                    if (tipo_inven == "DISCOS") {
                        productodis = productodis + " <div class='owl-item' style='width: 228px;'> "
                        productodis = productodis + " <div class='product-thumb'> "
                        productodis = productodis + "   <div class='image'><a href='product.html'><img src='https://3dev.com.co/Doom/Bootstrap/(S(dkuvl5elumrtdpvmdge5v35g))/ShowImage.ashx?ID=" + referencia + "&TIPO=FRENTE&COLOR=*&EMPRESA=01' alt='Aspire Ultrabook Laptop' title='Aspire Ultrabook Laptop' class='img-responsive'></a></div> "
                        productodis = productodis + "   <div class='caption'> "
                        productodis = productodis + "       <h4><a href='product.html'>" + nombre + "</a></h4> "
                        productodis = productodis + "       <p class='price'> <span class='price-new'>$230.00</span> <span class='price-old'>$" + precio + "</span> <span class='saving'>-25%</span> </p> "
                        productodis = productodis + "       <div class='rating'> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star-o fa-stack-2x'></i></span> </div> "
                        productodis = productodis + "   </div> "
                        productodis = productodis + "   <div class='button-group'> "
                        productodis = productodis + "       <button class='btn-primary' type='button' onclick=''><span>Add to Cart</span></button> "
                        productodis = productodis + "       <div class='add-to-links'> "
                        productodis = productodis + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to wishlist'><i class='fa fa-heart'></i></button> "
                        productodis = productodis + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to compare'><i class='fa fa-exchange'></i></button> "
                        productodis = productodis + "       </div> "
                        productodis = productodis + "   </div>"
                        productodis = productodis + " </div>"
                        productodis = productodis + " </div>"
                    }
                    if (tipo_inven == "EQUIPOS") {
                        productoequ = productoequ + " <div class='owl-item' style='width: 228px;'> "
                        productoequ = productoequ + " <div class='product-thumb'> "
                        productoequ = productoequ + "   <div class='image'><a href='product.html'><img src='https://3dev.com.co/Doom/Bootstrap/(S(dkuvl5elumrtdpvmdge5v35g))/ShowImage.ashx?ID=" + referencia + "&TIPO=FRENTE&COLOR=*&EMPRESA=01' alt='Aspire Ultrabook Laptop' title='Aspire Ultrabook Laptop' class='img-responsive'></a></div> "
                        productoequ = productoequ + "   <div class='caption'> "
                        productoequ = productoequ + "       <h4><a href='product.html'>" + nombre + "</a></h4> "
                        productoequ = productoequ + "       <p class='price'> <span class='price-new'>$230.00</span> <span class='price-old'>$" + precio + "</span> <span class='saving'>-25%</span> </p> "
                        productoequ = productoequ + "       <div class='rating'> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star-o fa-stack-2x'></i></span> </div> "
                        productoequ = productoequ + "   </div> "
                        productoequ = productoequ + "   <div class='button-group'> "
                        productoequ = productoequ + "       <button class='btn-primary' type='button' onclick=''><span>Add to Cart</span></button> "
                        productoequ = productoequ + "       <div class='add-to-links'> "
                        productoequ = productoequ + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to wishlist'><i class='fa fa-heart'></i></button> "
                        productoequ = productoequ + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to compare'><i class='fa fa-exchange'></i></button> "
                        productoequ = productoequ + "       </div> "
                        productoequ = productoequ + "   </div>"
                        productoequ = productoequ + " </div>"
                        productoequ = productoequ + " </div>"
                    }

                    if (tipo_inven == "MEMORIAS") {
                        productomem = productomem + " <div class='owl-item' style='width: 228px;'> "
                        productomem = productomem + " <div class='product-thumb'> "
                        productomem = productomem + "   <div class='image'><a href='product.html'><img src='https://3dev.com.co/Doom/Bootstrap/(S(dkuvl5elumrtdpvmdge5v35g))/ShowImage.ashx?ID=" + referencia + "&TIPO=FRENTE&COLOR=*&EMPRESA=01' alt='Aspire Ultrabook Laptop' title='Aspire Ultrabook Laptop' class='img-responsive'></a></div> "
                        productomem = productomem + "   <div class='caption'> "
                        productomem = productomem + "       <h4><a href='product.html'>" + nombre + "</a></h4> "
                        productomem = productomem + "       <p class='price'> <span class='price-new'>$230.00</span> <span class='price-old'>$" + precio + "</span> <span class='saving'>-25%</span> </p> "
                        productomem = productomem + "       <div class='rating'> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star-o fa-stack-2x'></i></span> </div> "
                        productomem = productomem + "   </div> "
                        productomem = productomem + "   <div class='button-group'> "
                        productomem = productomem + "       <button class='btn-primary' type='button' onclick=''><span>Add to Cart</span></button> "
                        productomem = productomem + "       <div class='add-to-links'> "
                        productomem = productomem + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to wishlist'><i class='fa fa-heart'></i></button> "
                        productomem = productomem + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to compare'><i class='fa fa-exchange'></i></button> "
                        productomem = productomem + "       </div> "
                        productomem = productomem + "   </div>"
                        productomem = productomem + " </div>"
                        productomem = productomem + " </div>"
                    }

                    if (tipo_inven == "TABLES") {
                        productotab = productotab + " <div class='owl-item' style='width: 228px;'> "
                        productotab = productotab + " <div class='product-thumb'> "
                        productotab = productotab + "   <div class='image'><a href='product.html'><img src='https://3dev.com.co/Doom/Bootstrap/(S(dkuvl5elumrtdpvmdge5v35g))/ShowImage.ashx?ID=" + referencia + "&TIPO=FRENTE&COLOR=*&EMPRESA=01' alt='Aspire Ultrabook Laptop' title='Aspire Ultrabook Laptop' class='img-responsive'></a></div> "
                        productotab = productotab + "   <div class='caption'> "
                        productotab = productotab + "       <h4><a href='product.html'>" + nombre + "</a></h4> "
                        productotab = productotab + "       <p class='price'> <span class='price-new'>$230.00</span> <span class='price-old'>$" + precio + "</span> <span class='saving'>-25%</span> </p> "
                        productotab = productotab + "       <div class='rating'> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star fa-stack-2x'></i><i class='fa fa-star-o fa-stack-2x'></i></span> <span class='fa fa-stack'><i class='fa fa-star-o fa-stack-2x'></i></span> </div> "
                        productotab = productotab + "   </div> "
                        productotab = productotab + "   <div class='button-group'> "
                        productotab = productotab + "       <button class='btn-primary' type='button' onclick=''><span>Add to Cart</span></button> "
                        productotab = productotab + "       <div class='add-to-links'> "
                        productotab = productotab + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to wishlist'><i class='fa fa-heart'></i></button> "
                        productotab = productotab + "           <button type='button' data-toggle='tooltip' title='' onclick='' data-original-title='Add to compare'><i class='fa fa-exchange'></i></button> "
                        productotab = productotab + "       </div> "
                        productotab = productotab + "   </div>"
                        productotab = productotab + " </div>"
                        productotab = productotab + " </div>"

                    }


                    


                });


                producto = producto + " </div> </div>";
                $('#carusel_portatil').append(producto);

                productosum = productosum + " </div> </div>";
                $('#carusel_suministros').append(productosum);

                productocel = productocel + " </div> </div>";
                $('#carusel_celular').append(productocel);

                productodis = productodis + " </div> </div>";
                $('#carusel_discos').append(productodis);

                productoequ = productoequ + " </div> </div>";
                $('#carusel_equipos').append(productoequ);

                productomem = productomem + " </div> </div>";
                $('#carusel_memorias').append(productomem);

                productotab = productotab + " </div> </div>";
                $('#carusel_tables').append(productotab);


            },
            error: function (xhr, msg) {
                alert(msg + '\n' + xhr.responseText);
            }

        });



        test = function (Filtro) {
            var producto = "";
            alert("text");

            $('#carusel_portatil').empty();
            $('#carusel_suministros').empty();
            $('#carusel_celular').empty();
            $('#carusel_discos').empty();
            $('#carusel_equipos').empty();
            $('#carusel_memorias').empty();
            $('#carusel_tables').empty();
        }

    }

});