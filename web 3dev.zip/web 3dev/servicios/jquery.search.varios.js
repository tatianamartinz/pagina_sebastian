﻿(function ($) {
    //var URL = "http://localhost:47643/GestionMovil/Datos/WebDatos.asmx/manDataxml";
    var URL = "http://web.ibisfashion.com.co/web/Bootstrap/Datos/WebDatos.asmx/manDataxml";

    BuscarItems = function (Filtro) {
        var consulta = ""
        consulta = consulta + "<PagXml>                                ";
        consulta = consulta + "   <CorXml>                              ";
        consulta = consulta + "      <CODIGO>0058</CODIGO>             ";
        consulta = consulta + "      <NOMBRE>PROCESO</NOMBRE>          ";
        consulta = consulta + "      <ORDEN>1</ORDEN>                  ";
        consulta = consulta + "      <VALOR><![CDATA[EMPRESA.AGENCIAS]]></VALOR>   ";
        consulta = consulta + "      <FILTRO><![CDATA[]]></FILTRO> ";
        consulta = consulta + "   </CorXml>                             ";
        consulta = consulta + "</PagXml>                               ";

        //alert(consulta);
        //
        $('#table td').remove();
        $('#table tr').remove();

        //var table = document.getElementById("table");

        var table = $("#tiendas");
        
        

        jQuery.ajax({
            type: "POST",
            url: URL,
            data: "Parametros=" + consulta + "",
            success: function (data) {
                var xml_string = jQuery(data).text();
                var table_row = "";
                var nombre_ant = "";
                //alert(xml_string);
                
                table_row = table_row + "<div class='col-md-4 contact_left'> ";
                $(xml_string).find('DATOS').each(function () {
                    nombre = $(this).find("CIUDAD").text();
                    direccion = $(this).find("N_DIRECCION").text();
                    
                    if (nombre_ant != nombre && nombre != "" ) 
                    {
                        table_row = table_row + "</br>"
                        //table_row = table_row + "<div class='contact_grid contact_address'>";
                        table_row = table_row + "	<h3>" + nombre + "</h3> </b>";
                        //table_row = table_row + "</div>";
                    }
                    
                    nombre_ant = nombre; 
                    table_row = table_row + "	<p>" + direccion + "</p>";
                });
                table_row = table_row + "</div>";
                
                table.html(table_row);
                
            },
            error: function (xhr, msg) {
                alert("1" + msg + '\n' + xhr.responseText);
            }
        })
    }


    BuscarItemsII = function (Filtro) {
        $('#table td').remove();
        var table_row = "";
        table_row = table_row + "<tr> ";
        table_row = table_row + "	<td>" + "hola mundo" + "</td>";
        table_row = table_row + "</tr>";
        $('#table tr:last').after(table_row);
    }

})(jQuery);