﻿(function ($) {
    var URL = "http://localhost:47646/GestionMovil/Datos/WebDatos.asmx/manDataxml";
    var URL = "http://web.maravilla.com.co/Maravilla/Doom/Bootstrap/Datos/WebDatos.asmx/manDataxml";

    BuscarItems = function (Filtro) {
        
        var consulta = ""
        consulta = consulta + "<PagXml>                                ";
        consulta = consulta + "   <CorXml>                             ";
        consulta = consulta + "      <TIPO>PARAMETRO</TIPO>            ";
        consulta = consulta + "      <CODIGO>0056</CODIGO>             ";
        consulta = consulta + "      <NOMBRE>PROCESO</NOMBRE>          ";
        consulta = consulta + "      <ORDEN>1</ORDEN>                  ";
        consulta = consulta + "      <VALOR><![CDATA[EMPRESA.CONTACTOS]]></VALOR>   ";
        consulta = consulta + "      <FILTRO><![CDATA[" + Filtro + "]]></FILTRO>     ";
        consulta = consulta + "   </CorXml>                             ";
        consulta = consulta + "</PagXml>                               ";



        //alert(consulta);
        //
        $('#table td').remove();
        $('#table tr').remove();


        //var table = document.getElementById("table");
        var table = $("#tiendas");


        jQuery.ajax({
            type: "POST",
            url: URL,
            data: "Parametros=" + consulta + "",
            success: function (data) {
                var xml_string = jQuery(data).text();
                alert(xml_string);
                $(xml_string).find('Datos').each(function () {
                    var table_row = "";

                    nombre = $(this).find("NOMBRE").text()
                    ide = $(this).find("IDENTIFICACION").text()

                    //alert(nombre);
                    table_row = table_row + "<tr onclick='SeleccionFiltro(this);'> ";
                    table_row = table_row + "	<td>" + nombre + "</td>";
                    table_row = table_row + "	<td>" + ide + "</td>";
                    table_row = table_row + "</tr>";
                    $('#tdbusCLientes tr:last').after(table_row);
                });
            },
            error: function (xhr, msg) {
                alert(msg + '\n' + xhr.responseText);
            }
        })




    }


    BuscarItemsII = function (Filtro) {
        $('#table td').remove();
        var table_row = "";
        table_row = table_row + "<tr> ";
        table_row = table_row + "	<td>" + "hola mundo" + "</td>";
        table_row = table_row + "</tr>";
        $('#table tr:last').after(table_row);
    }

})(jQuery);