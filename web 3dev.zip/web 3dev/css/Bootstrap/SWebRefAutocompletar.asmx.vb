﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data.SqlClient

' Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente.
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class SWebRefAutocompletar
    Inherits System.Web.Services.WebService
#Region "Variables de manejo de datos"
    Dim tbrec As New AdmDatos
    Dim BASE_SISTEMA As String = "SERVERI_MAR"
#End Region

#Region "Inicia sistema {}"
    Sub New()
        Call carga_empresa()
        BASE_SISTEMA = mbase_empresa.base_pricipal
    End Sub
#End Region

#Region "Funciones autocompletar inventarios {ObtListaReferencias}"
    <WebMethod()>
    Public Function ObtListaReferencias(ByVal prefixText As String, ByVal count As Integer, ByVal contextKey As String) As String()
        Dim reader1 As SqlDataReader
        reader1 = tbrec.DataReader("select REFERENCIA from [dbx.INVEN].dbo.ITEMS where SUCURSAL ='" & contextKey & "' AND  REFERENCIA LIKE '" & prefixText & "%' ORDER BY REFERENCIA ", BASE_SISTEMA)
        Dim lista As New List(Of String)
        While reader1.Read
            lista.Add(reader1.Item("REFERENCIA"))
        End While
        Return lista.ToArray
    End Function


    <WebMethod()>
    Public Function ObtListaReferenciasnombre(ByVal prefixText As String, ByVal count As Integer, ByVal contextKey As String) As String()
        Dim reader1 As SqlDataReader
        reader1 = tbrec.DataReader("select NOMBRE + ' : ' + REFERENCIA AS REFERENCIA from [dbx.INVEN].dbo.ITEMS where SUCURSAL ='" & contextKey & "' AND  NOMBRE LIKE '%" & prefixText & "%' ORDER BY NOMBRE ", BASE_SISTEMA)
        Dim lista As New List(Of String)
        While reader1.Read
            lista.Add(reader1.Item("REFERENCIA"))
        End While
        Return lista.ToArray
    End Function


    <WebMethod()>
    Public Function ObtListaCiudadesNombre(ByVal prefixText As String, ByVal count As Integer, ByVal contextKey As String) As String()
        Dim reader1 As SqlDataReader
        Dim sql_filtro As String = ""
        If contextKey <> "" Then
            sql_filtro = contextKey
        End If
        reader1 = tbrec.DataReader("select NOMBRE + ' : ' + CODIGO AS CIUDAD from [dbx.GENE].dbo.CIUDADES where NOMBRE LIKE '%" & prefixText & "%' " & sql_filtro & " ORDER BY NOMBRE ", BASE_SISTEMA)
        Dim lista As New List(Of String)
        While reader1.Read
            lista.Add(reader1.Item("CIUDAD"))
        End While
        Return lista.ToArray
    End Function


    <WebMethod()>
    Public Function ObtListaClientesIdentificacion(ByVal prefixText As String, ByVal count As Integer, ByVal contextKey As String) As String()
        Dim reader1 As SqlDataReader
        reader1 = tbrec.DataReader("select IDENTIFICACION + ' : ' + NOMBRE AS IDENTIFICACION from [dbx.GENE].dbo.CLIENTES where IDENTIFICACION LIKE '%" & prefixText & "%' ORDER BY IDENTIFICACION ", BASE_SISTEMA)
        Dim lista As New List(Of String)
        While reader1.Read
            lista.Add(reader1.Item("IDENTIFICACION"))
        End While
        Return lista.ToArray
    End Function

#End Region



End Class