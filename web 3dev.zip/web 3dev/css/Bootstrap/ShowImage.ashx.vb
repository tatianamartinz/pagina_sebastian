﻿Imports System.Web
Imports System.Web.Services
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient

Public Class ShowImage
    Implements System.Web.IHttpHandler

#Region "Variables de manejo de datos"
    Dim tbrec As New AdmDatos
    Dim DocNom As New DataSet
    Dim mdata As DataSet
    Dim dtTallas As DataTable
    Dim sql_t As String = ""
    Dim SeImpresora As String = ""
#End Region

#Region "Variables de manejo de datos"
    Dim BASE_SISTEMA As String = "SERVERI_MAR"
#End Region

#Region "Inicia sistema {}"
    Sub New()
        Call carga_empresa()
        BASE_SISTEMA = mbase_empresa.base_pricipal
    End Sub
#End Region

#Region "Captura de Variables {}"
    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        Dim empno As String
        Dim tipo As String = ""
        Dim color As String = ""
        Dim empresa As String = ""

        If Not context.Request.QueryString("ID") Is Nothing Then
            empno = Convert.ToString(context.Request.QueryString("ID"))
            tipo = Convert.ToString(context.Request.QueryString("TIPO"))
            color = Convert.ToString(context.Request.QueryString("COLOR"))
            empresa = Convert.ToString(context.Request.QueryString("EMPRESA"))
        Else
            Throw New ArgumentException("No parameter specified")
        End If
        Try
            context.Response.ContentType = "image/jpeg"
            Dim strm As Stream = ShowEmpImage(empno, tipo, color, empresa)
            If Not strm Is Nothing Then
                Dim buffer As Byte() = New Byte(4095) {}
                Dim byteSeq As Integer = strm.Read(buffer, 0, 4096)
                Do While byteSeq > 0
                    context.Response.OutputStream.Write(buffer, 0, byteSeq)
                    byteSeq = strm.Read(buffer, 0, 4096)
                Loop
            End If
        Catch ex As Exception
        End Try
    End Sub
#End Region

#Region "Consulta por datos {}"
    Public Function ShowEmpImage(ByVal empno As String, tipo As String, color As String, empresa As String) As Stream
        mdata = tbrec.FindDataset("SELECT FOTO FROM [dbx.INVEN].dbo.FOTOS WHERE REFERENCIA = '" & empno & "' AND TIPO ='" & tipo & "' AND COLOR ='" & color & "' and SUCURSAL ='" & empresa & "'", BASE_SISTEMA, "Datos", 1)
        For Each p In mdata.Tables(0).Rows
            Dim img As Object = p(0)
            Try
                'img = System.Text.UnicodeEncoding.Convert(Encoding.Unicode, Encoding.Default, CType(img, Byte()))
                Return New MemorihӦx���T�/�%Z�������r�H�sY�X����s�J{��۠����Qfex /kjִD'>�f��$%�½�����$�1M�W#2lAV��!��ض�\wY��:�t\�F�[�'��n�n�u
�ɉd͝l�Ai�&�>u��Ì$���)g����c�;�)�\�ܵ�]���`�;���^$X?c0�h�	�������$kj����!wq���n7�3��lN���D��+�����!��[��F._�^�0:��jM�<���myA^��藜�J_�yh�4P����I�(�y�`�Ľ�`v����v�