﻿Imports System.Web
Imports System.Web.Services
Imports System.IO
Imports System.Data.SqlClient

Public Class ShowImageDoc
    Implements System.Web.IHttpHandler


#Region "Variables de manejo de datos"
    Dim tbrec As New AdmDatos
    Dim DocNom As New DataSet
    Dim mdata As DataSet
    Dim dtTallas As DataTable
    Dim sql_t As String = ""
    Dim SeImpresora As String = ""
#End Region

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        Dim empno As String
        If Not context.Request.QueryString("id") Is Nothing Then
            empno = Convert.ToString(context.Request.QueryString("id"))
        Else
            Throw New ArgumentException("No parameter specified")
        End If

        Try
            context.Response.ContentType = "image/jpeg"
            Dim strm As Stream = ShowEmpImage(empno)
            Dim buffer As Byte() = New Byte(4095) {}
            Dim byteSeq As Integer = strm.Read(buffer, 0, 4096)

            Do While byteSeq > 0
                context.Response.OutputStream.Write(buffer, 0, byteSeq)
                byteSeq = strm.Read(buffer, 0, 4096)
            Loop
        Catch ex As Exception
        End Try
    End Sub

    Public Function ShowEmpImage(ByVal empno As String) As Stream

        Dim conn As String = ""
        Dim SQL_T As String = ""
        Dim campo_base As String = ""
        If Left(empno, 1).ToUpper = "A" Then
            conn = "Data Source=" & "serveri\aviv" & ";Initial Catalog=" & "M700_TRA" & ";" & "User Id=" & "Remoto" & ";Password=" & "Maravilla1" & ";"
        Else
            conn = "Data Source=" & "serveri\maravilla" & ";Initial Catalog=" & "M700_TRA" & ";" & "User Id=" & "Remoto" & ";Password=" & "Maravilla1" & ";"
        End If
        SQL_T = "Select DATO as FOTO From DOC_IMAGENES Left Join DOC_RELACION On DOC_IMAGENES.NUMERO=DOC_RELACION.NUMERO Where DOC_RELACION.REL_CODIGO ='" & empno & "'"
        If SQL_T <> "" Then
            Dim connection As SqlConnection = New SqlConnection(conn)
            Dim sql As String = SQL_T
            Dim cmd As SqlCommand = New SqlCommand(sql, connection)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@ID", empno)
            connection.Open()
            Dim img As Object = cmd.ExecuteScalar()
            Try
                'img = System.Text.UnicodeEncoding.Convert(Encoding.Unicode, Encoding.Default, CType(img, Byte()))
                Return New MemoryStream(CType(img, Byte()))
            Catch
                Return Nothing
            Finally
                connection.Close()
            End Try
        Else
            Return Nothing
        End If
    End Function


    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class