﻿Imports System.Data.SqlClient

Public Class WebForm1
    Inherits System.Web.UI.Page

#Region "variables"
    Public Hallado As Boolean
    Dim tbrec As New AdmDatos
    Dim BASE_SISTEMA As String = "SERVERI_MAR"
#End Region

#Region "Inicia sistema {}"
    Sub New()
        Call carga_empresa()
        BASE_SISTEMA = mbase_empresa.base_pricipal
    End Sub
#End Region

#Region "Load"
    Private Sub WebForm1_Load(sender As Object, e As EventArgs) Handles Me.Load
        maneja_estado.Value = "no  requiere"
        If Request.Browser.Version = "8.0" Then
            Dim sms_nav As String = nav()
            LtlNavegador.Text = sms_nav
        End If

        If Not IsPostBack Then
            If Not (Request.Cookies("UserName") Is Nothing) Then
                TxtUsuario.Text = Request.Cookies("UserName").Value
            End If

            If ((Not (Request.Cookies("UserName")) Is Nothing) AndAlso (Not (Request.Cookies("Password")) Is Nothing)) Then
                TxtUsuario.Text = Request.Cookies("UserName").Value
                TxtClave.Text = Request.Cookies("Password").Value
                Login(Request.Cookies("UserName").Value, Request.Cookies("Password").Value)
            End If
        End If
    End Sub
#End Region

#Region "Boton de Login {Button1_Click}"
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call Login(TxtUsuario.Text, TxtClave.Text)
    End Sub
#End Region

#Region "Actualizar la clave del usuario"
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Rst As SqlDataReader
        Dim sms_error As String = ""
        Dim Script As String = ""
        Dim mLiteral As String = ""

        If TextClave1.Text <> TextClave2.Text Then
            If sms_error = "" Then
                sms_error = "<p class='text-alert' >La clave indicada debe ser la misma en ambos campos</p>" & vbCr
            Else
                sms_error = sms_error & "<p/>" & "<p class='text-alert' >La clave indicada debe ser la misma en ambos campos.</p>" & vbCr
            End If
        End If
        If TextClave1.Text = "" Or TextClave2.Text = "" Then
            If sms_error = "" Then
                sms_error = "<p class='text-alert' >Debe indicar la clave en ambos campos.</p>" & vbCr
            Else
                sms_error = sms_error & "<p/>" & "<p class='text-alert' >Debe indicar la clave en ambos campos.</p>" & vbCr
            End If
        End If
        If Len(TextClave1.Text) < 8 Then
            If sms_error = "" Then
                sms_error = sms_error & "<p class='text-alert' >Debe indicar al menos 8 caracteres</p>" & vbCr
            Else
                sms_error = sms_error & "<p/>" & "<p class='text-alert' >Debe indicar al menos 8 caracteres</p>" & vbCr
            End If
        End If

        Ltlerror.Text = ""
        If sms_error <> "" Then
            TextClave1.Text = ""
            TextClave2.Text = ""
            mLiteral = ""
            mLiteral = mLiteral & " <div class='alert alert-danger fade in' id='cert-error' >"
            mLiteral = mLiteral & "     <button type='button' class='close' aria-hidden='true' onclick='closeAlert();'>"
            mLiteral = mLiteral & "         x</button>"
            mLiteral = mLiteral & "     <h2>Juuum, Ha ocurrido un error.</h2>"
            mLiteral = mLiteral & "         " & sms_error & "  "
            mLiteral = mLiteral & "</div>"
            Ltlerror.Text = mLiteral
            Exit Sub
        End If

        Rst = tbrec.DataReader("select * from [dbx.GENE].dbo.directorio where EMAIL ='" & TxtUsuario.Text & "' or IDENTIFICACION ='" & TxtUsuario.Text & "' ", BASE_SISTEMA)
        While Rst.Read
            tbrec.Execute("UPDATE [dbx.GENE].dbo.DIRECTORIO SET CLAVECCS = '" & TextClave1.Text & "', FLAG_CLAVE = 0 WHERE IDENTIFICACION ='" & Rst("IDENTIFICACION") & "'  ", BASE_SISTEMA)
            Call Login(TxtUsuario.Text, TextClave1.Text)
        End While
    End Sub
#End Region

#Region "Login Login {Usuario = string clave = String}"
    Public Sub Login(Usuario As String, clave As String)
        Dim sql_t As String = ""
        Dim Rst As SqlDataReader
        Dim script As String = ""


        script = script & "<script>"
        script = script & " var variable =  document.getElementById('maneja_estado').value ;"
        script = script & " if (variable == 'requiere')  "
        script = script & " { "
        script = script & "    $('.modal').addClass('in'); "
        script = script & "    $('#myModal').show();"
        script = script & " } "
        script = script & "</script>"

        maneja_estado.Value = "no  requiere"

        sql_t = ""
        sql_t = sql_t & " SELECT * "
        sql_t = sql_t & " from [dbx.GENE].dbo.DIRECTORIO "
        sql_t = sql_t & " where (EMAIL ='" & Trim(Usuario) & "' or IDENTIFICACION ='" & Trim(Usuario) & "' "
        sql_t = sql_t & "        or REPLACE (LEFT( IDENTIFICACION  , CASE WHEN PATINDEX('%-%' , IDENTIFICACION ) = 0 THEN LEN(IDENTIFICACION) ELSE PATINDEX('%-%' , IDENTIFICACION ) END) , '-','') = '" & Trim(Usuario) & "')"
        Rst = tbrec.DataReader(sql_t, BASE_SISTEMA)
        Hallado = False
        While Rst.Read
            '// Valida si requiere resetear a clave
            If Rst("FLAG_CLAVE") = 1 Then
                maneja_estado.Value = "requiere"
                ClientScript.RegisterStartupScript(Page.GetType(), "Show", script)
            Else
                If Trim(clave) = Rst("CLAVECCS") Then
                    maneja_estado.Value = "no  requiere"
                    VariablesGlobales.Usuario = Usuario
                    Session("Usuario") = Rst("IDENTIFICACION")
                    Session("Nombre") = Rst("NOMBRE")
                    If CheckRecordar.Checked = True Then
                        Dim Cooki As HttpCookie = New HttpCookie("webmaravilla_com_co")
                        Dim exp As New Date
                        exp = Date.Now
                        exp = exp.AddDays(30.0)
                        Cooki.Values.Add("RECORDAR", "SI")
                        Cooki.Values.Add("USUARIO", Usuario)
                        Cooki.Expires = exp
                        Response.Cookies.Add(Cooki)
                    End If
                    Response.Redirect("~/MenuPrincipal.aspx")
                    Hallado = True
                Else
                    Hallado = False
                End If
            End If
        End While

        If Hallado = False Then lblMensaje.Text = "Error datos de entrada ..."
    End Sub
#End Region

#Region "Mesage para internet explorer"

    Public Function nav() As String
        Dim sms_nav As String
        sms_nav = ""

        sms_nav = sms_nav & " <table style='height: 276px; width: 435px'>"
        sms_nav = sms_nav & " 	<tr>"
        sms_nav = sms_nav & " 		<td style='width: 203px; height: 102px;'>"
        sms_nav = sms_nav & " 		<img alt='' height='98' src='Imagenes/thumb.jpg' width='205'></td>"
        sms_nav = sms_nav & " 		<td style='height: 102px; width: 44px'></td>"
        sms_nav = sms_nav & " 		<td style='width: 181px; height: 102px;'>"
        sms_nav = sms_nav & " 	    <font face='fontawesome' size='4' color='gray'>"
        sms_nav = sms_nav & " 		<h3 style='width: 257px; height: 81px'>Lo sentimos tu navegador no es compatiple, <br>puedes probar con los"
        sms_nav = sms_nav & " 		siguientes navegadores</h3>"
        sms_nav = sms_nav & " 		</font><strong>:</strong></td>"
        sms_nav = sms_nav & " 	</tr>"
        sms_nav = sms_nav & " 	<tr>"
        sms_nav = sms_nav & " 		<td style='height: 21px; width: 203px;'></td>"
        sms_nav = sms_nav & " 		<td style='height: 21px; width: 44px;'>"
        sms_nav = sms_nav & " 		<img alt='' height='16' src='Imagenes/Opera_256x2561.png' width='18'></td>"
        sms_nav = sms_nav & " 		<td style='height: 21px; width: 181px;'>"
        sms_nav = sms_nav & " 		&nbsp;<a href='http://opera.es.downloadable.co/?c=163&amp;gclid=Cj0KEQjw06GfBRCR9tDI4t6n5_MBEiQAFo6kuPSzcS-Kr7Ant30eCvBAVrU3uzyvgL-8l5KYQ_bIUpUaAlu38P8HAQ' class='auto-style6'>Opera&nbsp; "
        sms_nav = sms_nav & " 		</a> </td>"
        sms_nav = sms_nav & " 		<td style='height: 21px'>"
        sms_nav = sms_nav & " 	</tr>"
        sms_nav = sms_nav & " 	<tr>"
        sms_nav = sms_nav & " 		<td style='height: 23px; width: 203px;'></td>"
        sms_nav = sms_nav & " 		<td style='height: 23px; width: 44px;'>"
        sms_nav = sms_nav & " 		<img alt='' height='19' src='Imagenes/firefox.png' width='18'></td>"
        sms_nav = sms_nav & " 		<td style='height: 23px; width: 181px'>"
        sms_nav = sms_nav & " 		&nbsp;<a href='https://www.mozilla.org/es-ES/firefox/new/' class='auto-style6'>Firefox&nbsp;</a></td>"
        sms_nav = sms_nav & " 	</tr>"
        sms_nav = sms_nav & " 	<tr>"
        sms_nav = sms_nav & " 		<td style='width: 203px; height: 23px;'></td>"
        sms_nav = sms_nav & " 		<td style='width: 44px; height: 23px'>"
        sms_nav = sms_nav & " 		<img alt='' height='20' src='Imagenes/google-chrome-logo.png' width='18'></td>"
        sms_nav = sms_nav & " 		<td style='width: 181px; height: 23px;'>"
        sms_nav = sms_nav & " 		&nbsp;<a href='http://www.google.com/intl/es-419/chrome/' class='auto-style6'>Chrome</a></td>"
        sms_nav = sms_nav & " 	</tr>"
        sms_nav = sms_nav & " 	<tr>"
        sms_nav = sms_nav & " 		<td style='width: 203px; height: 61px;'>&nbsp;</td>"
        sms_nav = sms_nav & " 		<td style='width: 44px; height: 61px'>"
        sms_nav = sms_nav & " 		<img alt='' height='19' src='Imagenes/ie10.png' width='19'></td>"
        sms_nav = sms_nav & " 		<td style='width: 181px; height: 61px;'>&nbsp;O actualizar tu navegador a<a href='http://internet-explorer.joydownload.es/?c=163&amp;gclid=Cj0KEQjw06GfBRCR9tDI4t6n5_MBEiQAFo6kuK9QD8R0h8MeSs6mJrcToaCz8TsIR23yOfK5u2F-ARcaAnMj8P8HAQ' class='auto-style6'>&nbsp;&nbsp;&nbsp; internet explorer 9</a> o&nbsp; superior.&nbsp; </td>"
        sms_nav = sms_nav & " 	</tr>"
        sms_nav = sms_nav & " </table>"

        Return sms_nav
    End Function

    Private Sub CheckRecordar_CheckedChanged(sender As Object, e As EventArgs) Handles CheckRecordar.CheckedChanged
        If CheckRecordar.Checked Then
            Response.Cookies("UserName").Expires = DateTime.Now.AddDays(30)
            Response.Cookies("Password").Expires = DateTime.Now.AddDays(30)
        Else
            Response.Cookies("UserName").Expires = DateTime.Now.AddDays(-1)
            Response.Cookies("Password").Expires = DateTime.Now.AddDays(-1)
        End If
        Response.Cookies("UserName").Value = TxtUsuario.Text.Trim
        Response.Cookies("Password").Value = TxtClave.Text.Trim
    End Sub



#End Region


End Class